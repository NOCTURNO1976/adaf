package com.prodestino.manaus

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.prodestino.manaus.location.ForegroundLocationService
import com.prodestino.manaus.overlay.OverlayService

class MainActivity : AppCompatActivity() {

    // ===== Estado geral =====
    private lateinit var webView: WebView
    private var bootCompletedOnce = false
    private var resumed = false
    private var pageReady = false
    private var serviceStarted = false

    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var lastRecoverAt = 0L
    private var isOfflineShown = false

    // URL que está sendo tentada (ex.: y.php). Usada para retorno pós-offline.
    private var pendingUrl: String? = null

    private val ui = Handler(Looper.getMainLooper())

    // Permissões pendentes do getUserMedia
    private var pendingWebPermission: PermissionRequest? = null

    // File chooser callback
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = filePathCallback
        filePathCallback = null
        if (callback == null) return@registerForActivityResult
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val uri: Uri? = data?.data
            if (uri != null) callback.onReceiveValue(arrayOf(uri)) else callback.onReceiveValue(null)
        } else {
            callback.onReceiveValue(null)
        }
    }

    // Página offline (fallback interno, caso asset falhe)
    private val OFFLINE_FALLBACK_HTML: String by lazy {
        """
        <!doctype html><html lang="pt-br"><meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Sem conexão</title>
        <style>html,body{height:100%}body{font-family:system-ui,Arial,sans-serif;margin:0;display:grid;place-items:center;background:#f7f7f7}
        .card{max-width:460px;margin:24px;padding:24px;text-align:center;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.08);background:#fff}
        h1{font-size:18px;margin:0 0 8px}p{color:#555;margin:0}</style>
        <div class="card" role="status" aria-live="polite">
          <h1>Sem conexão</h1><p>Volte ao app quando a internet estiver disponível.</p>
        </div></html>
        """.trimIndent()
    }

    // ===== Preferências simples =====
    private val uiPrefs by lazy { getSharedPreferences("app_prefs", MODE_PRIVATE) }
    private var lastGoodUrl: String?
        get() = uiPrefs.getString("last_good_url", null)
        set(v) { uiPrefs.edit().putString("last_good_url", v).apply() }

    private fun isBubbleEnabled(): Boolean =
        uiPrefs.getBoolean("bubble_enabled", false)

    private fun setBubbleEnabled(enabled: Boolean) {
        uiPrefs.edit().putBoolean("bubble_enabled", enabled).apply()
    }

    // ===== Bridge exposto ao JavaScript =====
    private inner class WebBridge(private val ctx: Context) {

        /** Liga/Desliga a bolha (serviço de overlay) */
        @JavascriptInterface
        fun overlay(mode: String?) {
            val m = (mode ?: "").lowercase()
            when (m) {
                "on" -> {
                    setBubbleEnabled(true)
                    if (hasOverlayPermissionInternal()) {
                        startOverlayService(OverlayService.ACTION_SHOW)
                    } else {
                        requestOverlayPermissionIfNeeded()
                    }
                }
                "off" -> {
                    setBubbleEnabled(false)
                    startOverlayService(OverlayService.ACTION_HIDE)
                }
                else -> { // toggle
                    val newState = !isBubbleEnabled()
                    setBubbleEnabled(newState)
                    if (newState) {
                        if (hasOverlayPermissionInternal()) {
                            startOverlayService(OverlayService.ACTION_SHOW)
                        } else {
                            requestOverlayPermissionIfNeeded()
                        }
                    } else {
                        startOverlayService(OverlayService.ACTION_HIDE)
                    }
                }
            }
        }

        /** Abre a tela do sistema para conceder a permissão de sobreposição */
        @JavascriptInterface
        fun ensureOverlayPermission() {
            requestOverlayPermissionIfNeeded()
        }

        /** Retorna se o app já pode desenhar sobre outros apps */
        @JavascriptInterface
        fun hasOverlayPermission(): Boolean = hasOverlayPermissionInternal()

        /** Estado atual desejado (persistido) da bolha */
        @JavascriptInterface
        fun isBubbleEnabled(): Boolean = this@MainActivity.isBubbleEnabled()

        /** Chamado pelo offline.html para recuperar a navegação após erro/offline */
        @JavascriptInterface
        fun recoverFromOffline() {
            this@MainActivity.runOnUiThread {
                recoverFromOfflineOnce()
            }
        }
    }

    // ===== Utilitários de permissão/efeitos =====
    private fun vibrate(ms: Long = 60) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(
                    VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun hasFineOrCoarse(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    private fun hasCamera(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hasMic(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasOverlayPermissionInternal(): Boolean =
        Settings.canDrawOverlays(this)

    private fun requestOverlayPermissionIfNeeded() {
        if (!hasOverlayPermissionInternal()) {
            val i = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
    }

    /**
     * Inicia o serviço da bolha com segurança:
     * - SHOW/TOGGLE: usa startForegroundService (Android O+)
     * - HIDE: usa startService (para não forçar startForeground sem necessidade)
     */
    private fun startOverlayService(action: String) {
        val i = Intent(this, OverlayService::class.java).apply { this.action = action }
        val isShow = action == OverlayService.ACTION_SHOW || action == OverlayService.ACTION_TOGGLE
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (isShow) startForegroundService(i) else startService(i)
            } else {
                startService(i)
            }
        } catch (_: Exception) { /* evita crash em OEMs mais restritos */ }
    }

    private val reqForegroundPerms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { maybeStartService(); proceedIfReady() }

    private val reqCamMicPerms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val grantedCamera = results[Manifest.permission.CAMERA] == true
        val grantedMic = results[Manifest.permission.RECORD_AUDIO] == true
        pendingWebPermission?.let { req ->
            val needsVideo = req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
            val needsAudio = req.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
            val okVideo = !needsVideo || grantedCamera
            val okAudio = !needsAudio || grantedMic
            if (okVideo && okAudio) req.grant(req.resources) else req.deny()
            pendingWebPermission = null
        }
    }

    private fun ensureForegroundLocationOnce() {
        if (!hasFineOrCoarse()) {
            reqForegroundPerms.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun ensureCamMicOnce() {
        val need = mutableListOf<String>()
        if (!hasCamera()) need += Manifest.permission.CAMERA
        if (!hasMic())    need += Manifest.permission.RECORD_AUDIO
        if (need.isNotEmpty()) reqCamMicPerms.launch(need.toTypedArray())
    }

    private fun normalizedBase(): String {
        val base = BuildConfig.BASE_URL.ifBlank { "https://adaf.sistema.prodestino.com" }
        return base.trimEnd('/') + "/"
    }

    private fun originMatchesBase(origin: String?): Boolean {
        if (origin.isNullOrBlank()) return false
        val base = normalizedBase().removeSuffix("/")
        return try {
            val o = Uri.parse(origin)
            val b = Uri.parse(base)
            val oHost = (o.host ?: "").lowercase()
            val bHost = (b.host ?: "").lowercase()
            val oScheme = (o.scheme ?: "https").lowercase()
            val bScheme = (b.scheme ?: "https").lowercase()
            (oHost == bHost) && (oScheme == bScheme)
        } catch (_: Exception) { false }
    }

    private fun isOffline(): Boolean = isOfflineShown

    private fun saveWebCookie(cookie: String?) {
        if (!cookie.isNullOrBlank()) {
            uiPrefs.edit().putString("web_cookie", cookie).apply()
        }
    }

    private fun flushCookies() {
        try { CookieManager.getInstance().flush() } catch (_: Exception) {}
    }

    private fun maybeStartService() {
        if (serviceStarted) return
        if (!pageReady) return
        if (!hasFineOrCoarse()) return
        try {
            ForegroundLocationService.start(this)
            serviceStarted = true
        } catch (_: Throwable) {
            ui.postDelayed({
                try { ForegroundLocationService.start(this); serviceStarted = true } catch (_: Throwable) {}
            }, 1000L)
        }
    }

    // ===== Checagem real de rede =====
    private fun hasNetworkConnection(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false

            // VALIDATED = já passou pelos checks de conectividade real
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ||
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    // ==== helpers para abrir apps externos (Waze / Maps / WhatsApp) =====

    private fun openWaze(uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                `package` = "com.waze"
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=com.waze")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) { }
        }
    }

    private fun openGoogleMaps(uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                `package` = "com.google.android.apps.maps"
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: ActivityNotFoundException) {
                try {
                    startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("market://details?id=com.google.android.apps.maps")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) { }
            }
        }
    }

    private fun openWhatsAppFromHttp(uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=com.whatsapp")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) { }
        }
    }

    // ===== WebView (sem Service Worker) =====
    @SuppressLint("SetJavaScriptEnabled")
    private fun initWebViewIfNeeded() {
        if (this::webView.isInitialized && webView.url != null) return

        webView = WebView(this)
        setContentView(webView)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.setGeolocationEnabled(true)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.mediaPlaybackRequiresUserGesture = false
        s.userAgentString = s.userAgentString + " ProDestinoWebView/1.0"

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.addJavascriptInterface(WebBridge(this), "Android")

        val base = normalizedBase()

        webView.webViewClient = object : WebViewClient() {
            private fun showOfflineScreen() {
                if (isOfflineShown) return
                isOfflineShown = true

                // Garante um alvo pra recuperação
                if (pendingUrl == null) {
                    pendingUrl = lastGoodUrl ?: normalizedBase()
                }

                val b = normalizedBase()
                try {
                    webView.loadUrl("file:///android_asset/offline.html")
                } catch (_: Throwable) {
                    webView.loadDataWithBaseURL(
                        b,
                        OFFLINE_FALLBACK_HTML,
                        "text/html",
                        "UTF-8",
                        null
                    )
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme?.lowercase() ?: return false
                val host = (uri.host ?: "").lowercase()

                // 1) Schemes específicos → sempre fora do WebView
                if (scheme == "waze") {
                    openWaze(uri)
                    return true
                }

                if (scheme in listOf("intent","whatsapp","tel","mailto","market")) {
                    try {
                        val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    } catch (_: ActivityNotFoundException) {
                        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Throwable) {}
                    } catch (_: Throwable) {}
                    return true
                }

                // 2) Schemas não HTTP/HTTPS → tenta via Intent genérico
                if (scheme != "http" && scheme != "https") {
                    try {
                        val generic = Intent(Intent.ACTION_VIEW, uri)
                        generic.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(generic)
                    } catch (_: Throwable) { }
                    return true
                }

                // 3) HTTP/HTTPS: tratar Maps e wa.me fora do WebView
                if (scheme == "http" || scheme == "https") {
                    if (host == "wa.me" || host == "api.whatsapp.com") {
                        openWhatsAppFromHttp(uri)
                        return true
                    }

                    val pathLower = (uri.path ?: "").lowercase()
                    val isGoogleMapsHost =
                        host == "maps.google.com" ||
                            host == "maps.app.goo.gl" ||
                            (host.endsWith(".google.com") && pathLower.startsWith("/maps"))
                    if (isGoogleMapsHost) {
                        openGoogleMaps(uri)
                        return true
                    }

                    if (host.endsWith(".")) {
                        val fixed = Uri.Builder()
                            .scheme(uri.scheme ?: "https")
                            .encodedAuthority(host.trimEnd('.'))
                            .encodedPath(uri.encodedPath)
                            .encodedQuery(uri.encodedQuery)
                            .build().toString()
                        pendingUrl = fixed
                        view.loadUrl(fixed)
                        return true
                    }

                    // Navegação normal dentro do domínio: marca como tentativa (pending)
                    val target = uri.toString()
                    if (target.startsWith(base)) {
                        pendingUrl = target
                    }
                    return false
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                val b = normalizedBase()
                // Se estamos começando a carregar uma página do domínio principal, ela vira pendingUrl
                if (url.startsWith(b)) {
                    pendingUrl = url
                }
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400) {
                    vibrate()
                    showOfflineScreen()
                }
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (request.isForMainFrame) {
                    vibrate()
                    showOfflineScreen()
                }
            }

            @Suppress("OVERRIDE_DEPRECATION")
            override fun onReceivedError(
                view: WebView,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                vibrate()
                showOfflineScreen()
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                vibrate()
                handler.cancel()
                showOfflineScreen()
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                val target = (pendingUrl ?: lastGoodUrl ?: base)
                safeRecreateWebView(target)
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)

                if (url.startsWith("chrome-error://")) {
                    vibrate()
                    showOfflineScreen()
                    return
                }

                val isGood = url.startsWith(base)
                if (isGood) {
                    pageReady = true
                    isOfflineShown = false
                    lastGoodUrl = url
                    try {
                        saveWebCookie(CookieManager.getInstance().getCookie(base))
                    } catch (_: Exception) { }
                    maybeStartService()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val allow = hasFineOrCoarse() && originMatchesBase(origin)
                callback?.invoke(origin, allow, false)
                if (!allow && !hasFineOrCoarse()) ensureForegroundLocationOnce()
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                val originOk = originMatchesBase(request.origin?.toString())
                val resources = request.resources ?: emptyArray()
                val needsVideo = resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                val needsAudio = resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                if (!originOk) {
                    request.deny()
                    return
                }
                val haveEverything = (!needsVideo || hasCamera()) && (!needsAudio || hasMic())
                if (haveEverything) {
                    request.grant(resources)
                    return
                }
                pendingWebPermission = request
                val need = mutableListOf<String>()
                if (needsVideo && !hasCamera()) need += Manifest.permission.CAMERA
                if (needsAudio && !hasMic())    need += Manifest.permission.RECORD_AUDIO
                if (need.isNotEmpty()) {
                    reqCamMicPerms.launch(need.toTypedArray())
                } else {
                    request.deny()
                    pendingWebPermission = null
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*","application/pdf"))
                }
                val chooser = Intent.createChooser(intent, "Selecionar arquivo")
                fileChooserLauncher.launch(chooser)
                return true
            }
        }

        val startUrl = lastGoodUrl ?: base
        pendingUrl = startUrl
        webView.loadUrl(startUrl)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun safeRecreateWebView(targetUrl: String) {
        try {
            if (this::webView.isInitialized) {
                try { (webView.parent as? android.view.ViewGroup)?.removeView(webView) } catch (_: Exception) {}
                try { webView.destroy() } catch (_: Exception) {}
            }
        } catch (_: Exception) {}

        webView = WebView(this)
        setContentView(webView)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.setGeolocationEnabled(true)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.mediaPlaybackRequiresUserGesture = false
        s.userAgentString = s.userAgentString + " ProDestinoWebView/1.0"

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.addJavascriptInterface(WebBridge(this), "Android")

        initWebViewClientsForRecreatedInstance()

        val base = normalizedBase()
        val urlToLoad = if (targetUrl.isNotBlank()) targetUrl else base
        pendingUrl = urlToLoad
        isOfflineShown = false
        webView.loadUrl(urlToLoad)
    }

    private fun initWebViewClientsForRecreatedInstance() {
        val base = normalizedBase()

        webView.webViewClient = object : WebViewClient() {
            private fun showOfflineLocal() {
                if (isOfflineShown) return
                isOfflineShown = true

                // Garante um alvo pra recuperação
                if (pendingUrl == null) {
                    pendingUrl = lastGoodUrl ?: normalizedBase()
                }

                val b = normalizedBase()
                try {
                    webView.loadUrl("file:///android_asset/offline.html")
                } catch (_: Throwable) {
                    webView.loadDataWithBaseURL(
                        b,
                        OFFLINE_FALLBACK_HTML,
                        "text/html",
                        "UTF-8",
                        null
                    )
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme?.lowercase() ?: return false
                val host = (uri.host ?: "").lowercase()

                if (scheme == "waze") {
                    openWaze(uri)
                    return true
                }

                if (scheme in listOf("intent","whatsapp","tel","mailto","market")) {
                    try {
                        val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    } catch (_: ActivityNotFoundException) {
                        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Throwable) {}
                    } catch (_: Throwable) {}
                    return true
                }

                if (scheme != "http" && scheme != "https") {
                    try {
                        val generic = Intent(Intent.ACTION_VIEW, uri)
                        generic.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(generic)
                    } catch (_: Throwable) { }
                    return true
                }

                if (scheme == "http" || scheme == "https") {
                    if (host == "wa.me" || host == "api.whatsapp.com") {
                        openWhatsAppFromHttp(uri)
                        return true
                    }

                    val pathLower = (uri.path ?: "").lowercase()
                    val isGoogleMapsHost =
                        host == "maps.google.com" ||
                            host == "maps.app.goo.gl" ||
                            (host.endsWith(".google.com") && pathLower.startsWith("/maps"))
                    if (isGoogleMapsHost) {
                        openGoogleMaps(uri)
                        return true
                    }

                    if (host.endsWith(".")) {
                        val fixed = Uri.Builder()
                            .scheme(uri.scheme ?: "https")
                            .encodedAuthority(host.trimEnd('.'))
                            .encodedPath(uri.encodedPath)
                            .encodedQuery(uri.encodedQuery)
                            .build().toString()
                        pendingUrl = fixed
                        view.loadUrl(fixed)
                        return true
                    }

                    val target = uri.toString()
                    if (target.startsWith(base)) {
                        pendingUrl = target
                    }
                    return false
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                val b = normalizedBase()
                if (url.startsWith(b)) {
                    pendingUrl = url
                }
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400) {
                    vibrate()
                    showOfflineLocal()
                }
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (request.isForMainFrame) {
                    vibrate()
                    showOfflineLocal()
                }
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                vibrate()
                handler.cancel()
                showOfflineLocal()
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                val target = (pendingUrl ?: lastGoodUrl ?: base)
                safeRecreateWebView(target)
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                val isGood = url.startsWith(base)
                if (isGood) {
                    pageReady = true
                    isOfflineShown = false
                    lastGoodUrl = url
                    try {
                        saveWebCookie(CookieManager.getInstance().getCookie(base))
                    } catch (_: Exception) { }
                    maybeStartService()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val allow = hasFineOrCoarse() && originMatchesBase(origin)
                callback?.invoke(origin, allow, false)
                if (!allow && !hasFineOrCoarse()) ensureForegroundLocationOnce()
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                val originOk = originMatchesBase(request.origin?.toString())
                val resources = request.resources ?: emptyArray()
                val needsVideo = resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                val needsAudio = resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                if (!originOk) {
                    request.deny()
                    return
                }
                val haveEverything = (!needsVideo || hasCamera()) && (!needsAudio || hasMic())
                if (haveEverything) {
                    request.grant(resources)
                    return
                }
                pendingWebPermission = request
                val need = mutableListOf<String>()
                if (needsVideo && !hasCamera()) need += Manifest.permission.CAMERA
                if (needsAudio && !hasMic())    need += Manifest.permission.RECORD_AUDIO
                if (need.isNotEmpty()) {
                    reqCamMicPerms.launch(need.toTypedArray())
                } else {
                    request.deny()
                    pendingWebPermission = null
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*","application/pdf"))
                }
                val chooser = Intent.createChooser(intent, "Selecionar arquivo")
                fileChooserLauncher.launch(chooser)
                return true
            }
        }
    }

    // ===== Lifecycle =====
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//// GRAVAR TELA
     window.setFlags(   
     WindowManager.LayoutParams.FLAG_SECURE,
     WindowManager.LayoutParams.FLAG_SECURE
     )
  
        initWebViewIfNeeded()

        ensureForegroundLocationOnce()
        ensureCamMicOnce()
        askIgnoreBatteryOptimizations() // agora só pergunta 1 vez

        // Listener de rede para recuperar da offline.html
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            netCb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    // Sempre tenta recuperar quando a rede fica disponível
                    ui.postDelayed({ recoverFromOfflineOnce() }, 500L)
                }
            }
            cm.registerDefaultNetworkCallback(netCb!!)
        } catch (_: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        hideSystemBars()
        proceedIfReady()

        startOverlayService(OverlayService.ACTION_HIDE)

        if (!hasOverlayPermissionInternal() && isBubbleEnabled()) {
            setBubbleEnabled(false)
        }

        // Se a tela atual é a offline.html, tenta recuperar
        val currentUrl = if (this::webView.isInitialized) (webView.url ?: "") else ""
        if (currentUrl.startsWith("file:///android_asset/offline.html")) {
            recoverFromOfflineOnce()
        }
    }

    override fun onPause() {
        super.onPause()
        resumed = false
    }

    override fun onStop() {
        super.onStop()
        flushCookies()
        if (isBubbleEnabled() && hasOverlayPermissionInternal()) {
            startOverlayService(OverlayService.ACTION_SHOW)
        } else {
            startOverlayService(OverlayService.ACTION_HIDE)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            netCb?.let { cm.unregisterNetworkCallback(it) }
        } catch (_: Exception) { }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        vibrate(40)
        // Intencionalmente não chama super.onBackPressed()
    }

    // ===== Helpers =====
    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { c ->
                c.hide(android.view.WindowInsets.Type.navigationBars())
                c.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    // Agora com comportamento "uma vez só"
    private fun askIgnoreBatteryOptimizations() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            val pkg = packageName

            // Se já está fora da otimização, não faz nada
            if (pm.isIgnoringBatteryOptimizations(pkg)) {
                return
            }

            // Se já perguntamos uma vez, não insiste mais
            val alreadyAsked = uiPrefs.getBoolean("asked_ignore_battery", false)
            if (alreadyAsked) {
                return
            }

            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$pkg")
            }
            startActivity(i)

            // Marca que já perguntamos
            uiPrefs.edit().putBoolean("asked_ignore_battery", true).apply()
        } catch (_: Exception) { }
    }

    /** Prossegue quando: app visível + localização OK */
    private fun proceedIfReady() {
        if (!resumed) return
        if (!hasFineOrCoarse()) return
        if (!bootCompletedOnce) {
            bootCompletedOnce = true
            ui.postDelayed({ maybeStartService() }, 250L)
        }
    }

    private fun recoverFromOfflineOnce() {
        // Throttle pra não ficar tentando em loop rápido
        val now = SystemClock.elapsedRealtime()
        if (now - lastRecoverAt < 1200L) return
        lastRecoverAt = now

        // Se ainda não tem rede de verdade, nem tenta sair da OFF
        if (!hasNetworkConnection()) {
            return
        }

        val target = pendingUrl ?: lastGoodUrl ?: normalizedBase()

        webView.post {
            try {
                // Libera o flag pra permitir novas OFF no futuro
                isOfflineShown = false
                webView.loadUrl(target)
            } catch (_: Throwable) {
                safeRecreateWebView(target)
            }
        }
    }
}
